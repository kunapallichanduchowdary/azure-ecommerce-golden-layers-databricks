# E-Commerce Pipeline (21M to 50M Records)

This repository showcases a complete Azure + Databricks data pipeline processing over 21 million raw e-commerce events, scalable to 50M+.

## Architecture
- **Bronze Layer**: Raw ingestion from Azure Blob Storage (CSV)
- **Silver Layer**: PySpark transformations & cleaning
- **Golden Layer**: 25 business insights (Delta tables) like top brands, abandoned carts, revenue, etc.
- **Power BI Ready**: All Delta tables registered for analytics

## Tech Stack
Azure Data Factory | Azure Databricks | PySpark | Delta Lake | Power BI | ADLS Gen2

## Notebooks
- `silver_transformations.ipynb`: Full pipeline from ingestion to golden layer creation

## Data
- Sample data in `/sample-data/` (CSV) [Replace with actual or mock data]

## Author
Kunapalli Chandu
